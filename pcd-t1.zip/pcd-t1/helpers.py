import socket


class Conn:

    addr = (socket.gethostname(), 12345)
    buff = 65000

    def __init__(self, protocol, is_server=False):
        self.proto = protocol.lower()
        self.is_server = is_server
        if self.proto == "tcp":
            self.sok = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

            if is_server:
                self.sok.bind(self.addr)
                self.conn = None
                self.cl_addr = None
                self.sok.listen(1)
            else:
                self.sok.connect(self.addr)
        else:
            self.sok = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            if is_server:
               self.sok.bind(self.addr)

    def prepare(self):
        if self.proto == "tcp":
            self.conn, self.cl_addr = self.sok.accept()

    def send_data(self, data):
        if self.proto == "tcp":
            if self.is_server:
                self.conn.send(data)
            else:
                self.sok.send(data)
        else:
            self.sok.sendto(data, self.addr)

    def rec_data(self):
        self.sok.settimeout(4)
        if self.proto == "tcp":
            if self.is_server:
                return self.conn.recv(self.buff)
            return self.sok.recv(self.buff)
        else:
            return self.sok.recvfrom(self.buff)

    def shutdown_sok(self):
        self.sok.shutdown(socket.SHUT_WR)

    def close_conn(self):
        if self.proto == "tcp":
            self.conn.close()

    def close_sok(self):
        if self.proto == "tcp":
            self.sok.close()

    def get_proto(self):
        return self.proto

