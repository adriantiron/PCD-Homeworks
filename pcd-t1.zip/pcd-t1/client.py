from helpers import *
from time import time

mb = "1000"  # Available options: 50, 200, 500, 1000 (MB)
stop_and_wait = False

cl_obj = Conn("tcp")  # Available options: TCP, UDP
print("Conn done, sending", mb, "MB.\n")

total_msg = 0
total_bytes = 0
trans_time = time()

with open(mb + ".txt", "rb") as fd:
    byt = fd.read(cl_obj.buff)

    while byt:
        total_msg += 1
        total_bytes += len(byt)

        print('Sending', len(byt), 'bytes')
        cl_obj.send_data(byt)
        byt = fd.read(cl_obj.buff)

        if stop_and_wait:
            print("Waiting for ACK...")
            ack = cl_obj.rec_data()

trans_time = time() - trans_time
print("Done Sending...")
print("\nTransmission time:", trans_time, "\nBytes sent:", total_bytes, "\nMsg sent", total_msg)
cl_obj.shutdown_sok()
cl_obj.close_sok()  # Close the socket when done
