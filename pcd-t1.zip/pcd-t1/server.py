from helpers import *
from time import sleep

stop_and_wait = False

sv_obj = Conn("tcp", is_server=True)  # Available options: TCP, UDP
print("Init done, waiting for clients.\n")
total_msg = 0
total_bytes = 0

try:
    while True:

        sv_obj.prepare()

        data = sv_obj.rec_data()
        if len(data) == 2:
            data = data[0]

        nb_bytes = len(data)
        print('Received', nb_bytes, 'bytes')

        while data:
            total_msg += 1
            total_bytes += nb_bytes

            if stop_and_wait:
                print("Sending ACK...")
                sv_obj.send_data(b'\x11')

            print('Received', nb_bytes, 'bytes')
            data = sv_obj.rec_data()
            if len(data) == 2:
                data = data[0]

except socket.timeout:
    print("Done receiving, moving on...")
    print("\nProtocol:", sv_obj.get_proto(), "\nBytes read:", total_bytes, "\nMsg read:", total_msg, '\n')
    sv_obj.close_conn()
    sv_obj.close_sok()
    exit(1)
